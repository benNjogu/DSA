package com.keytech.RooMateFDR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RooMateFdrApplicationTests {

	@Test
	void contextLoads() {
	}

}
