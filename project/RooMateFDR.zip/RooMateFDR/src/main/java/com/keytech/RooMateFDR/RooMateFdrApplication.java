package com.keytech.RooMateFDR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RooMateFdrApplication {

	public static void main(String[] args) {
		SpringApplication.run(RooMateFdrApplication.class, args);
	}

}
